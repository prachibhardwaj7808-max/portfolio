# Prachi Bhardwaj — Personalized Portfolio

## Files
- `index.html` — page content and structure
- `style.css` — responsive styling, photo placeholders, and theme colors
- `script.js` — light/dark mode, mobile navigation, automatic copyright year

## Run locally
1. Extract this ZIP.
2. Open `prachi_portfolio/index.html` in your browser.
3. Edit the files using a code editor such as Visual Studio Code.

## Add your actual photo
The page currently has styled photo placeholders. To show your actual photo:
1. Copy your image into this folder and name it `prachi-photo.jpg` (or choose another filename).
2. In `index.html`, replace the `.profile-photo-placeholder` and/or `.about-photo-placeholder` placeholder elements with an image, for example:
   `<img class="profile-photo" src="prachi-photo.jpg" alt="Prachi Bhardwaj">`
3. Add CSS such as:
   `.profile-photo { width: 175px; height: 175px; object-fit: cover; border-radius: 50%; }`

## Before publishing
- Confirm the college and program wording is correct.
- Check that all public profile links work.
- Only add skills you can explain and real projects you have built.
- Your email and social links are included as provided.
